-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS paula_donations CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE paula_donations;

-- Tabela de pedidos
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    external_id VARCHAR(255) NOT NULL,
    order_id VARCHAR(255) NOT NULL,
    platform VARCHAR(100) DEFAULT 'operação',
    payment_method VARCHAR(50) DEFAULT 'pix',
    status VARCHAR(50) DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    approved_date DATETIME NULL,
    refunded_at DATETIME NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_document VARCHAR(20) NOT NULL,
    total_amount INT NOT NULL DEFAULT 0,
    commission_amount INT NOT NULL DEFAULT 0,
    currency VARCHAR(10) DEFAULT 'BRL',
    utm_source VARCHAR(255) NULL,
    utm_medium VARCHAR(255) NULL,
    utm_campaign VARCHAR(255) NULL,
    utm_content VARCHAR(255) NULL,
    utm_term VARCHAR(255) NULL,
    src VARCHAR(255) NULL,
    sck VARCHAR(255) NULL,
    is_test BOOLEAN DEFAULT FALSE,
    INDEX idx_external_id (external_id),
    INDEX idx_order_id (order_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- Tabela de produtos do pedido
CREATE TABLE IF NOT EXISTS order_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    unit_price INT NOT NULL DEFAULT 0,
    quantity INT NOT NULL DEFAULT 1,
    tangible BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    INDEX idx_order_id (order_id),
    INDEX idx_product_id (product_id)
);

-- Tabela de doações (para tracking adicional)
CREATE TABLE IF NOT EXISTS donations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10,2) NOT NULL,
    donor_name VARCHAR(255) NULL,
    donor_email VARCHAR(255) NULL,
    payment_method VARCHAR(50) DEFAULT 'pix',
    status VARCHAR(50) DEFAULT 'completed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    utm_source VARCHAR(255) NULL,
    utm_medium VARCHAR(255) NULL,
    utm_campaign VARCHAR(255) NULL,
    utm_content VARCHAR(255) NULL,
    utm_term VARCHAR(255) NULL,
    INDEX idx_amount (amount),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
); 